To compile all the source files contained in this zip folder type the command:

make

into the command problem. Now Follow these procedures to rum each program.

1. To run the My Compress file type one of the following commands.

./01-compress <input file>  // an output file will be auto generated
./01-compress <input file> <output file>


2. To run the My Deompress file type one of the following commands.

./02-decompress <input file>  // an output file will be auto generated
./02-decompress <input file> <output file>


3. To run the Fork Compress file type one of the following commands.

./03-forkcompress <input file>  // an output file will be auto generated
./03-forkcompress <input file> <output file>

4. To run the Pipe Compress file type one of the following commands.

./04-pipecompress <input file>  // an output file will be auto generated
./04-pipecompress <input file> <output file>

5. To run the Par Fork file type one of the following commands.

./05-parfork <input file>  // an output file will be auto generated
./05-parfork <input file> <output file>
./05-parfork <input file> <output file> <num of processess>


6. To rin the Minishell type the following command
./06-minishell

7. To rin the Minishell type the following command
./07-moreshell

8. To rin the Minishell type the following command
./08-dupshell

9. To run the Par Thread file type one of the following commands.

./09-parthread <input file>  // an output file will be auto generated
./09-parthread <input file> <output file>
./09-parthread <input file> <output file> <num of threads>